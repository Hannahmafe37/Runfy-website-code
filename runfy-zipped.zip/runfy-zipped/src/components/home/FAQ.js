import React from "react";
import clsx from "classnames";
import styled from "styled-components";
import bg from "assets/svgs/faq-bg.svg";
import { ReactComponent as ArrowRight } from "assets/svgs/arrow-right.svg";
import { ReactComponent as Dumbbell } from "assets/svgs/dumbbells.svg";

const FAQContainer = styled.div`
  background-position: center;
  background-image: url(${bg});
  background-size: cover;
  background-repeat: no-repeat;
`;

const Article = styled.article`
  background: linear-gradient(#1b1c1c, #1b1c1c) padding-box,
    linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%) border-box;
  border-radius: 12.2px;
  border: 0.41px solid transparent;
  input.tgg-title {
    appearance: unset;
    all: unset;
  }
  .faq-accordion-title label {
    display: flex;
    align-items: center;
    cursor: pointer;
  }

  .faq-accordion-title span {
    margin-left: auto;
    transition: transform 0.4s ease-in-out;
  }

  /* FAQ card: main content */
  /*================================================*/

  .faq-accordion-content {
    color: var(--neutral-soft-color);
    overflow: hidden;
    max-height: 0;
    transition: max-height 0.4s ease-in-out;
  }

  /* Effects */
  /*================================================*/

  /* main title, accordion title effects */

  /* onclick "" */
  .tgg-title:checked + div > label > h2 {
    font-weight: 700;
  }

  .tgg-title:checked + div > label > span {
    will-change: transform;
    transform: rotate(180deg);
  }

  /* main content, acordion text effect */

  .tgg-title:checked ~ .faq-accordion-content {
    will-change: max-height;
    max-height: 400px;
  }
`;

const questions = [
  {
    question: "What is Runfy?",
    answer: `Runfy Project is a 100% community-driven platform that empowers members to take control of their health and wellness. Runfy Project promotes everything relating to health and fitness while allowing users to earn.
  `,
  },
  {
    question: "How do I get  runfy?",
    answer: `You can purchase $RNF through our exclusive presale. Towards the end of the presale we will announce the exchanges that we will be listed on.
  `,
  },
  {
    question: "Why Runfy?",
    answer: `Runfy Project is at the front edge of the most inventive advances, keeping enormous centralized brands on their toes. The team has a simple task to leverage cutting-edge technologies to create products that will be accessible to all community members.
  `,
  },
  {
    question: "What is the Maximum Token Supply of $RNF?",
    answer: `There will only ever be 1 billion $RNF tokens in circulation.`,
  },
];

const FAQItem = ({ question, answer, index, className }) => {
  return (
    <Article
      className={clsx(
        "faq-accordion relative py-[10px] px-4 be:py-[25px] be:px-[40px]",
        className
      )}
    >
      <input
        type="checkbox"
        className="tgg-title absolute-fill"
        id={`tgg-title-1-${index}`}
      />
      <div className="faq-accordion-title">
        <label htmlFor={`tgg-title-1-${index}`}>
          <h2 className="text-white text-sm">{question}</h2>
          <span className="arrow-icon">
            <ArrowRight />
          </span>
        </label>
      </div>

      <div className="faq-accordion-content">
        <p className="text-white text-sm">{answer}</p>
      </div>
    </Article>
  );
};

const FAQ = () => {
  return (
    <div id="faq">
      <FAQContainer className="centers flex-col space-y-[30px] pt-[30px] be:pt-[100px]">
        <h3 className="gg-text font-bold text-center be:text-[49px]">FAQs</h3>
        <div className="flex flex-col space-y-[21.8px] px-6 w-full centers">
          {questions.map((question, index) => (
            <FAQItem
              key={index}
              className="be:!rounded-[30px] be:max-w-[950px] w-full"
              question={question.question}
              answer={question.answer}
              index={index}
            />
          ))}
        </div>
      </FAQContainer>
      <div className="mt-[100px] centers">
        <Dumbbell />
      </div>
    </div>
  );
};

export default FAQ;
