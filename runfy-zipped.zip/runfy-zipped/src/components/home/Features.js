import React from "react";
import clsx from "classnames";
import { ReactComponent as LadyRunning } from "assets/svgs/lady-running.svg";
import { ReactComponent as LadyRunningBig } from "assets/svgs/lady-running-big.svg";
import { ReactComponent as DottedCircles } from "assets/svgs/dotted-circles.svg";
import DottedCirclesBig from "assets/svgs/dotted-circles-big.svg";
import { ReactComponent as Reward } from "assets/svgs/reward.svg";
import { ReactComponent as Strength } from "assets/svgs/strength.svg";
import { ReactComponent as Transparency } from "assets/svgs/transparency.svg";
import { ReactComponent as Technology } from "assets/svgs/technology.svg";
import styled from "styled-components";

const StyledFeature = styled.div`
  border-radius: 28px;
  position: relative;
  ::after {
    content: "";
    position: absolute;
    height: 100%;
    width: 100%;
    top: 0;
    left: 0;
    background: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%);
    opacity: 0.1;
    border-radius: 28px;
  }
`;

const FeaturesList = styled.div`
  @media (min-width: 1185px) {
    background-image: url(${DottedCirclesBig});
    background-position: center;
    background-size: cover;
  }
`;

const featuresList = [
  {
    text: "Rewarding token holders and other community members for reaching their fitness goals",
    icon: <Reward />,
  },
  {
    text: "Empowering community members to be in control of their health and fitness",
    icon: <Strength />,
  },
  {
    text: "Creating transparency, active community, and sustainable leadership",
    icon: <Transparency />,
  },
  {
    text: "Bringing cutting-edge technology and tools to the health and fitness industries",
    icon: <Technology />,
  },
];

const Features = () => {
  return (
    <div className="pt-8 relative pb-[94px]" id="features">
      <div className="absolute-fill centers be:hidden translate-y-[300px] pointer-events-none !h-auto">
        <DottedCircles />
      </div>
      <h1 className="hidden be:block mt-[160px] gg-text font-bold text-[49px] text-center">
        Features
      </h1>
      <div className="flex flex-col space-y-9 be:flex-row be:space-y-0 centers">
        <div className="centers">
          <LadyRunning className="be:hidden" />
          <LadyRunningBig className="hidden be:block max-w-[575px] max-h-[570px]" />
        </div>
        <div className="centers flex-col">
          <h3 className="gg-text text-center text-[25px] font-bold mb-[49px] be:hidden">
            Features
          </h3>
          <FeaturesList className="flex flex-col space-y-[10px] be:min-w-[988px] be:min-h-[988px] be:gap-x-[56px] be:gap-y-[59px] be:items-center be:justify-center be:grid be:grid-cols-2 be:space-y-0">
            {featuresList.map((feature, index) => (
              <StyledFeature
                className={clsx(
                  "px-[9px] pt-[15px] pb-[30px] be:self-end centers flex flex-col space-y-[10px] max-w-[342px] be:w-[194px] be:h-[224px]",
                  {
                    "be:ml-auto": index === 0,
                    "be:ml-auto be:!mb-auto": index === 2,
                    "be:!mb-auto": index === 3,
                  }
                )}
                key={index}
              >
                {feature.icon}
                <p className="text-[#D4D9D7] text-[13px] text-center">
                  {feature.text}
                </p>
              </StyledFeature>
            ))}
          </FeaturesList>
        </div>
      </div>
    </div>
  );
};

export default Features;
