import React from "react";
import styled from "styled-components";
import { LINKS } from "utils/constants";
import { ReactComponent as Rays } from "assets/svgs/rays.svg";
import { ReactComponent as ManSwimming } from "assets/svgs/man-swimming.svg";
import { ReactComponent as LargeManSwimming } from "assets/svgs/large-man-swimming.svg";

export const GradientEllipse = styled.div`
  position: absolute;
  width: 390px;
  height: 91.3px;
  left: ${(props) => props.left || "176px"};
  top: ${(props) => props.top || "428.52px"};
  background: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%);
  filter: blur(140.896px);
  transform: rotate(-50.87deg);
`;

const EnterPresaleButton = styled.a`
  padding: 14.9858px 28.4731px;
  width: 154.95px;
  height: 47.97px;
  background: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%);
  border-radius: 23.9773px;
  color: #000;
  font-size: 14.9858px;
`;

const WhitePaperButton = styled(EnterPresaleButton)`
  color: #fff;
  background: transparent;
  border: 0.75px solid #72e97e;
`;

const Hero = () => {
  return (
    <div
      className="h-screen relative pt-[145px] be:pt-0 overflow-hidden"
      id="hero"
    >
      <div className="pointer-events-none absolute w-full left-0 bottom-0">
        <Rays className="w-full h-full" />
      </div>
      <GradientEllipse />
      <div className="mt-[100px] be:mt-[15%]">
        <h1 className="z-[2] relative font-bold text-center text-[33.28px] md:text-[63.58px] md:leading-[65px] text-[#FBFBFB] leading-[47.24px]">
          Take control of your
        </h1>
        <h1 className="z-[2] relative font-bold text-center text-[33.28px] md:text-[63.58px] md:leading-[65px] text-[#72E97E] leading-[47.24px]">
          health <span className="text-[#FBFBFB]">and</span> wellness.
        </h1>
        <h1 className="z-[2] relative font-bold text-center text-[33.28px] md:text-[63.58px] md:leading-[60px] text-[#FBFBFB] leading-[47.24px]">
          while earning <span className="text-[#72E97E]">crypto</span>
        </h1>
        <div className="z-[2] relative mt-[45px] md:mt-[33px] space-x-[23.23px] centers mb-[3px]">
          <EnterPresaleButton
            href={LINKS.presale}
            target="_blank"
            rel="noreferrer"
          >
            Enter presale
          </EnterPresaleButton>
          <WhitePaperButton
            href={LINKS.whitepaper}
            target="_blank"
            rel="noreferrer"
          >
            Whitepaper
          </WhitePaperButton>
        </div>
        <div className="w-screen overflow-hidden absolute bottom-[-100px] left-0 z-[1] be:hidden pointer-events-none">
          <ManSwimming />
        </div>
      </div>
      <div className="w-screen overflow-hidden absolute bottom-0 left-0 be:block hidden pointer-events-none">
        <LargeManSwimming className="w-full" />
      </div>
    </div>
  );
};

export default Hero;
