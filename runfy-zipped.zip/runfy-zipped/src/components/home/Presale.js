import React from "react";
import styled from "styled-components";
import { ReactComponent as LargeArcUp } from "assets/svgs/large-arc-up.svg";
import { ReactComponent as ArcUp } from "assets/svgs/arc-up.svg";
import { ReactComponent as IBT } from "assets/svgs/brands/ibt.svg";
import { ReactComponent as IBTBig } from "assets/svgs/brands/ibt-large.svg";
import { ReactComponent as CoinCheckupBig } from "assets/svgs/brands/coin-checkup-big.svg";
import { ReactComponent as CoinCheckup } from "assets/svgs/brands/coin-checkup.svg";
import { ReactComponent as BenzingaBig } from "assets/svgs/brands/benzinga-big.svg";
import { ReactComponent as Benzinga } from "assets/svgs/brands/benzinga.svg";
import { ReactComponent as NewsBtc } from "assets/svgs/brands/news-btc.svg";
import { ReactComponent as NewsBtcBig } from "assets/svgs/brands/news-btc-big.svg";
import { ReactComponent as CoinTelegraph } from "assets/svgs/brands/coin-telegraph.svg";
import { ReactComponent as CoinTelegraphBig } from "assets/svgs/brands/coin-telegraph-big.svg";
import { ReactComponent as RestingCoins } from "assets/svgs/resting-coins.svg";
import { ReactComponent as RestingCoinsBig } from "assets/svgs/resting-coins-big.svg";
import { useCountdown } from "hooks/useCountdown";
import { presale2Date } from "utils/constants";

const GlowingEllipse = styled.div`
  pointer-events: none;
  position: absolute;
  top: 100px;
  left: 186px;
  background: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%);
  filter: blur(103.036px);
  transform: matrix(1, 0, 0, -1, 0, 0);
  width: 195px;
  height: 45px;
`;

const Blurry = styled.div`
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(5.33654px);
  position: relative;

  h3 {
    font-family: "Inter";
    font-style: normal;
    font-weight: 600;
    color: white;
  }

  .dots {
    position: absolute;
    width: 2.13px;
    height: 9.61px;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(5.33654px);
  }

  .dots.left {
    left: 0;
    border-radius: 2.13462px 0px 0px 2.13462px;
    transform: rotate(-180deg);
  }
  .dots.right {
    border-radius: 0px 2.13462px 2.13462px 0px;
    transform: rotate(-180deg);
    right: 0;
  }
`;

const GradientLine = styled.div`
  border-width: 1px;
  border-style: solid;
  border-image: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%) 1;
`;

const GradientBorder = styled.div`
  position: absolute;
  right: -41px;
  height: 100px;
  background: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%);
  width: 1px;
  top: 10px;
`;

const Presale = () => {
  const [days, hours, minutes, seconds] = useCountdown(presale2Date);
  const times = [
    { name: "days", value: days },
    { name: "hours", value: hours },
    { name: "minutes", value: minutes },
    { name: "seconds", value: seconds },
  ];

  return (
    <div className="bg-[#1B1C1C] relative">
      <GlowingEllipse className="z-[-1]" />
      <ArcUp className="mt-[-30px] xs:hidden mx-auto" />
      <LargeArcUp className="hidden xs:block translate-y-[-196px] mx-auto vvbe:translate-x-[13px]" />
      <div className="be:mt-[-260px]">
        <div className="mt-5 flex flex-col space-y-[30px]">
          <p className="text-white text-center">Presale stage 2 will end in</p>
          <div className="flex space-x-[25.62px] be:space-x-12 centers">
            {times.map((time, index) => (
              <div className="flex flex-col space-y-[2.67px]" key={index}>
                <Blurry className="centers w-[58.7px] h-[58.7px] be:w-[110px] be:h-[110px] rounded-[12.80px] be:rounded-3xl">
                  <div className="dots left" />
                  <div className="dots right" />
                  <h3 className="text-[34.15px] be:text-[64px]">
                    {time.value}
                  </h3>
                </Blurry>
                <span className="timespan text-center text-[7.47px] be:text-sm">
                  {time.name}
                </span>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-[46px] be:hidden">
          <h3 className="text-center text-[#72E97E] text-[25px] font-bold mb-3">
            Sign Up Bonus
          </h3>
          <p className="text-[10px] text-center text-white">
            Buy within 10 minutes to receive a{" "}
            <span className="text-[#72E97E]">25%</span> bonus.
          </p>
        </div>
        <div className="!hidden be:flex centers mt-[59px]">
          <div className="px-[40px] pt-[41px] pb-9 centers min-w-[380px] relative overflow-hidden border-[0.81px] border-[#72E97E] rounded-[6.5px]">
            <div className="inner-gradient absolute-fill" />
            <div className="flex flex-col space-y-[10px]">
              <h2 className="gg-text text-center font-bold text-[39px]">
                Sign up Bonus
              </h2>
              <p className="text-base text-white text-center">
                Buy within 10 minutes to receive a{" "}
                <span className="font-bold text-[31px]">25%</span> bonus.
              </p>
              <GradientLine className="w-full" />
              <div className="flex mt-2 space-x-[82px] centers">
                <div className="flex-col space-y-0 centers relative">
                  <GradientBorder />
                  <span className="gg-text text-[25px] text-center">
                    Presale stage 1
                  </span>
                  <span className="text-white text-center font-bold text-[31px]">
                    7% bonus
                  </span>
                </div>
                <div className="flex-col space-y-0 centers relative">
                  <GradientBorder />
                  <span className="gg-text text-[25px] text-center">
                    Presale stage 2
                  </span>
                  <span className="text-white text-center font-bold text-[31px]">
                    5% bonus
                  </span>
                </div>
                <div className="flex-col space-y-0 centers relative">
                  <GradientBorder />
                  <span className="gg-text text-[25px] text-center">
                    Presale stage 3
                  </span>
                  <span className="text-white text-center font-bold text-[31px]">
                    3% bonus
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-[46px] centers be:hidden">
          <div className="py-[46px] px-[42px] relative rounded-[4px] border-[0.54px] border-[#72E97E] flex flex-col space-y-[27px] centers">
            <div className="green-gradient-box absolute left-0 top-0 w-full h-full pointer-events-none" />
            <div className="flex flex-col space-y-[37px]">
              <div className="px-5 border-b-[0.66px] pb-[37px] border-b-[#72E97E]">
                <h2 className="text-[#72E97E] text-base mb-1 font-regular text-center">
                  Presale stage 1
                </h2>
                <h1 className="text-white font-bold text-xl text-center">
                  7% bonus
                </h1>
              </div>
              <div className="px-5 border-b-[0.66px] pb-[37px] border-b-[#72E97E]">
                <h2 className="text-[#72E97E] text-base mb-1 font-regular text-center">
                  Presale stage 2
                </h2>
                <h1 className="text-white font-bold text-xl text-center">
                  5% bonus
                </h1>
              </div>
              <div className="px-5 pb-[37px]">
                <h2 className="text-[#72E97E] text-base mb-1 font-regular text-center">
                  Presale stage 3
                </h2>
                <h1 className="text-white font-bold text-xl text-center">
                  3% bonus
                </h1>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-[120px]">
          <div className="flex space-x-[15px] justify-center xs:hidden">
            <IBT />
            <CoinCheckup />
            <Benzinga />
            <NewsBtc />
            <CoinTelegraph />
          </div>
          <div className="xs:flex justify-center space-x-[42px] hidden items-center">
            <IBTBig />
            <CoinCheckupBig />
            <BenzingaBig />
            <NewsBtcBig />
            <CoinTelegraphBig />
          </div>
          <div className="mt-[17.93px]">
            <RestingCoins className="w-full xs:hidden" />
            <RestingCoinsBig className="hidden xs:block w-full" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Presale;
