import React from "react";
import clsx from "classnames";
import styled from "styled-components";
import { ReactComponent as RoadMapFlag } from "assets/svgs/roadmap-flag.svg";
import { ReactComponent as RoadMapFlagBig } from "assets/svgs/roadmap-flag-big.svg";
import { ReactComponent as Gymers } from "assets/svgs/people-gyming.svg";
import { ReactComponent as GymersBig } from "assets/svgs/people-gyming-big.svg";
import { ReactComponent as Road } from "assets/svgs/road.svg";
import { ReactComponent as RoadMapBig } from "assets/svgs/roadmap-big.svg";
import { largeScreenClasses } from "utils/constants";

const RoadMapLight = styled.div`
  background: linear-gradient(
    176.98deg,
    #1b1c1c 21.14%,
    rgba(27, 28, 28, 0.27) 53.55%,
    rgba(89, 115, 115, 0.46) 102.95%
  );
`;

const RoadmapStageWrapper = styled.div`
  padding: 20px;
  border-radius: 30px;

  .absolute-fill {
    background: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%);
    border-radius: 30px;
    opacity: 0.1;
  }
  border: 0.81px solid #72e97e;
  min-width: 379px;
  @media (max-width: 419px) {
    min-width: 100%;
  }
`;

const roadmapStages = [
  {
    name: "Checkpoint 1",
    subStages: ["Platform Development", "Mobile App Development", "Marketing"],
  },
  {
    name: "Checkpoint 2",
    subStages: [
      "RNF Token Development",
      "Air Drop / Referral Rewards",
      "Pre-Sales",
    ],
  },
  {
    name: "Checkpoint 3",
    subStages: [
      {
        name: "Giveaway",
        subStages: ["Giveaway With Minimum Worth USD 20.00 /"],
      },
      {
        name: "Token Prize Staking",
        subStages: ["Launch the Staking Platform"],
      },
      { name: "Lending Platform", subStages: ["Launch of Lending Platform"] },
      { name: "Listing Cex", subStages: ["Listing on Top 5 Cex"] },
      {
        name: "Price Predictor Platform",
        subStages: ["Launch of Price Predictor Platform"],
      },
    ],
  },
  {
    name: "Checkpoint 4",
    subStages: [
      { name: "Marketplace", subStages: ["Collection with our Native Token"] },
      {
        name: "Contests",
        subStages: [`Contest Shill Twitter / Telegram / Youtube\nReddit`],
      },
      { name: "Stablecoin", subStages: ["To Expand the Ecosystem"] },
      {
        name: "Marketing and Partnerships",
        subStages: ["New Partnerships and More Marketing"],
      },
    ],
  },
  {
    name: "Finish Line",
    subStages: [
      {
        name: "DeFi Wallet",
        subStages: ["Launch of First Fitness-Based DeFi Wallet"],
      },
      {
        name: "Partnership",
        subStages: ["Grow and Build More Partnership"],
      },
    ],
  },
];

const RoadMap = () => {
  return (
    <div className="bg-[#1B1C1C]" id="roadmap">
      <div
        className={clsx(
          "pt-[25.74px] be:pt-[40px] relative",
          largeScreenClasses
        )}
      >
        <RoadMapLight className="absolute-fill" />
        <div className="relative z-[4]">
          <div className="w-full centers relative roadmap-bg">
            <RoadMapFlag className="be:hidden" />
            <RoadMapFlagBig className="hidden be:block" />
            <div className="absolute-fill flex flex-col items-center justify-center bottom-0 !top-auto !h-auto">
              <Gymers className="mb-[-8px] be:hidden" />
              <GymersBig className="hidden be:block w-full" />
            </div>
          </div>
        </div>
        <div className="relative be:bg-[#1B1C1C]">
          <div className="centers absolute-fill left-[92px] vbe:hidden">
            <Road className="pointer-events-none absolute top-0" />
          </div>
          <div className="pt-[51px] flex flex-col space-y-[30px] centers px-5 vbe:hidden">
            {roadmapStages.map((stage, index) => (
              <RoadmapStageWrapper key={index} className="relative">
                <div className="absolute-fill" />
                <h4 className="gg-text text-[13px] font-bold mb-1">
                  {stage.name}
                </h4>
                {stage.subStages.map((stage, index) => {
                  if (typeof stage === "object") {
                    return (
                      <div className="flex flex-col" key={index}>
                        <span className="text-[#D4D9D7] text-[13px] font-bold">
                          {stage.name}:
                        </span>
                        {stage.subStages.map((subStage, index) => (
                          <span
                            className="text-[#D4D9D7] block text-[13px]"
                            key={`stage-${index}`}
                          >
                            {subStage}
                          </span>
                        ))}
                      </div>
                    );
                  }
                  return (
                    <span
                      key={index}
                      className="text-[#D4D9D7] block text-[13px] font-bold"
                    >
                      {stage}
                    </span>
                  );
                })}
              </RoadmapStageWrapper>
            ))}
          </div>
          <div className="hidden ml-[-200px] vbe:block">
            <RoadMapBig className="mx-auto" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoadMap;
