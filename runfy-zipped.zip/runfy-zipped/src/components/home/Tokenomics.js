import React from "react";
import styled from "styled-components";
import { ReactComponent as TokenomicsIllustration } from "assets/svgs/tokenomics.svg";
import { ReactComponent as TokenomicsIllustrationBig } from "assets/svgs/tokenomics-big.svg";
import largewaves from "assets/svgs/large-waves.svg";
import TokenomicsRowIndicator from "./TokenomicsRowIndicator";

const TokenomicsTable = styled.div`
  border-width: 0.55px;
  border-style: solid;
  border-image: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%) 1;
  h4 {
    background: linear-gradient(180deg, #f44197 0%, #ff92c6 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    font-weight: 700;
    font-size: 10.9249px;
  }
  .row {
    border-width: 0.55px;
    border-style: solid;
    border-image: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%) 1;
  }
`;

const tokenomicsTableData = [
  {
    color: "#27C2F5",
    distribution: "Liquidity",
    amount: "400,000,000",
    percentage: "40%",
  },
  {
    color: "#FF9933",
    distribution: "Move To Earn",
    amount: "150,000,000",
    percentage: "15%",
  },
  {
    color: "#FD33FF",
    distribution: "Presale Supply",
    amount: "300,000,000",
    percentage: "30%",
  },
  {
    color: "#69FC47",
    distribution: "Ecosystem",
    amount: "100,000,000",
    percentage: "10%",
  },
  {
    color: "#69FC47",
    distribution: "Ecosystem",
    amount: "100,000,000",
    percentage: "10%",
  },
  {
    color: "#FFCD33",
    distribution: "Advisors",
    amount: "10,000,000",
    percentage: "1%",
  },
  {
    color: "#652F9B",
    distribution: "Team",
    amount: "40,000,000",
    percentage: "4%",
    hide_border: true,
  },
];

const Tokenomics = () => {
  return (
    <div className="relative">
      <div className="absolute-fill pointer-events-none hidden be:flex centers z-[3] !top-[150px]">
        <img src={largewaves} className="h-[1000px]" alt="large waves" />
      </div>
      <div className="bg-[#1B1C1C] pt-[51px]">
        <h3 className="gg-text text-[25px] text-center font-bold be:text-[49px]">
          Tokenomics
        </h3>
        <div className="centers mt-[-20px] be:items-start be:mt-[140px] flex flex-col be:flex-row be:space-x-[122px] be:justify-center">
          <TokenomicsIllustration className="be:hidden" />
          <div className="flex flex-col space-y-[10px] centers">
            <p className="text-center pink-gradient-text">
              1,000,000,000 Billion Runfy Tokens
            </p>
            <TokenomicsIllustrationBig className="hidden be:block z-[4]" />
          </div>
          <TokenomicsTable className="w-[89vw] be:max-w-[692px] z-[4]">
            <div className="flex items-center px-[4%] w-full pt-[15.3px] pb-[11.31px]">
              <div className="w-[36%]">
                <h4>TOKEN DISTRIBUTION</h4>
              </div>
              <div className="w-[33%]">
                <h4 className="text-center">TOKEN AMOUNT</h4>
              </div>
              <div className="w-[23%]">
                <h4 className="text-center">PERCENTAGE</h4>
              </div>
            </div>
            {tokenomicsTableData.map((row, index) => (
              <div
                className="flex items-center px-[4%] w-full pt-[15.3px] pb-[11.31px] row"
                key={index}
              >
                <div className="w-[36%] flex items-center space-x-[18.57px]">
                  <TokenomicsRowIndicator color={row.color} />
                  <span className="font-bold text-[#FFF6FC] text-[8.74px]">
                    {row.distribution}
                  </span>
                </div>
                <div className="w-[33%] centers">
                  <span className="text-[8.74px] text-[#fff6fc] text-center">
                    {row.amount}
                  </span>
                </div>
                <div className="w-[23%] centers">
                  <span className="text-[8.74px] text-[#fff6fc] text-center">
                    {row.percentage}
                  </span>
                </div>
              </div>
            ))}
          </TokenomicsTable>
        </div>
        <p className="mt-[31.75px] text-center pink-gradient-text be:hidden">
          1,000,000,000 Billion Runfy Tokens
        </p>
      </div>
    </div>
  );
};

export default Tokenomics;
