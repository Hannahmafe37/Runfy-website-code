import React from "react";

const TokenomicsRowIndicator = ({ color }) => (
  <svg
    width="18"
    height="11"
    viewBox="0 0 18 11"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M17.3294 10.2806C17.3294 6.74804 16.2339 3.30615 14.1997 0.448242L0.942139 10.2806H17.3294Z"
      fill={color}
    />
  </svg>
);

export default TokenomicsRowIndicator;
