import React from "react";
import styled from "styled-components";
import { ReactComponent as VisionAndMissionSvg } from "assets/svgs/vision-and-mission.svg";
import { ReactComponent as VisionAndMissionSvgLarge } from "assets/svgs/vision-and-mission-big.svg";
import { ReactComponent as RunfyText } from "assets/svgs/runfy-text.svg";
import { ReactComponent as RunfyTextBig } from "assets/svgs/runfy-text-big.svg";

const VisionAndMissionCardOverlay = styled.div`
  background: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%);
  opacity: 0.1;
  border-radius: 2.66206px;
`;

const VisionAndMission = () => {
  return (
    <div className="bg-[#1B1C1C] mt-[-37px]">
      <h2 className="text-[49px] gg-text font-bold text-center hidden be:block be:translate-y-[3px]">
        Vision & Mission
      </h2>
      <div className="centers be:hidden mt-[45px] pt-5">
        <VisionAndMissionSvg />
      </div>
      <div className="mt-[50px] centers flex-col be:hidden">
        <h3 className="gg-text text-[25px] font-bold text-center">
          Vision & Mission
        </h3>
        <div className="mt-[28px] centers">
          <div className="relative p-[18px] rounded-[6.5px] border-[0.81px] border-[#72E97E]">
            <VisionAndMissionCardOverlay className="absolute-fill pointer-events-none" />
            <p className="text-[13px] text-white text-center max-w-[315px]">
              Reaching your health fitness goals can sometimes be challenging
              without the right mindset, technology, and tools. The team at
              Runfy understands this and is aware of the challange involved; as
              such, they designed a system, a tool (software), to offer fitness
              enthusiasts the necessary tools needed to reach their fitness
              goals.
            </p>
            <p className="text-[13px] mt-8 text-white text-center max-w-[315px]">
              Regardless of your fitness goals, our system will let you track
              your calories and nutritional intake with ease. The app comes with
              customized and actionable tips to help you reach your fitness
              goals.
            </p>
          </div>
        </div>
        <div className="mt-8 overflow-hidden">
          <RunfyText />
        </div>
      </div>
      <div className="hidden be:flex mt-[50px] items-center justify-center space-x-[172px]">
        <div className="flex items-center justify-center">
          <div className="relative rounded-[6.5px] border-[0.81px] p-[70px] border-[#72E97E]">
            <VisionAndMissionCardOverlay className="absolute-fill pointer-events-none" />
            <p className="text-[13px] text-white text-center max-w-[386px]">
              Reaching your health fitness goals can sometimes be challenging
              without the right mindset, technology, and tools. The team at
              Runfy understands this and is aware of the challange involved; as
              such, they designed a system, a tool (software), to offer fitness
              enthusiasts the necessary tools needed to reach their fitness
              goals.
            </p>
            <p className="text-[13px] mt-8 text-white text-center max-w-[386px]">
              Regardless of your fitness goals, our system will let you track
              your calories and nutritional intake with ease. The app comes with
              customized and actionable tips to help you reach your fitness
              goals.
            </p>
          </div>
          <VisionAndMissionSvgLarge />
        </div>
      </div>
      <div className="!hidden be:!flex centers">
        <RunfyTextBig />
      </div>
    </div>
  );
};

export default VisionAndMission;
