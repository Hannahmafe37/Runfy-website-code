import React from "react";
import styled from "styled-components";
import { ReactComponent as ManGyming } from "assets/svgs/man-gyming.svg";
import { ReactComponent as Dummbell } from "assets/svgs/dumbbell.svg";
import { ReactComponent as ManGymingBig } from "assets/svgs/man-gyming-big.svg";
import { ReactComponent as GymEquipment } from "assets/svgs/large-gym-equipment.svg";
import { ReactComponent as LoneRestingCoin } from "assets/svgs/lone-resting-coin.svg";
import { ReactComponent as LoneRestingCoinBig } from "assets/svgs/lone-resting-coin-big.svg";

const WhatIsRunfyCardOverlay = styled.div`
  background: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%);
  opacity: 0.1;
  border-radius: 2.66206px;
`;

const WhatIsRunfy = () => {
  return (
    <div className="mt-3" id="about">
      <h2 className="text-[49px] gg-text my-[45px] text-center font-bold hidden be:block">
        What is Runfy?
      </h2>

      {/* small screens */}
      <div className="flex flex-col justify-center be:hidden">
        <div className="flex flex-col items-center w-full ">
          <ManGyming />
          <Dummbell />
        </div>
        <LoneRestingCoin className="w-full mt-[46px] be:hidden" />
      </div>

      {/* large screens */}
      <div className="hidden be:flex flex-col justify-center">
        <div className="be:flex justify-center hidden 2xl:ml-[300px]">
          <ManGymingBig />
          <GymEquipment />
        </div>
        <LoneRestingCoinBig className="w-full hidden be:block" />
      </div>

      <div className="flex flex-col space-y-7 centers be:hidden">
        <h2 className="gg-text font-bold text-[25px] text-center">
          What is Runfy?
        </h2>
        <div className="py-6 px-4 relative border-[0.81px] border-[#72E97E] rounded-[6.5px]">
          <WhatIsRunfyCardOverlay className="absolute-fill pointer-events-none" />
          <div className="flex flex-col space-y-8">
            <p className="text-[13px] text-white text-center max-w-[315px]">
              Runfy is a 100% community-driven platform that empowers members to
              take control of their health and wellness.
            </p>
            <p className="text-[13px] text-white text-center max-w-[315px]">
              Runfy Token promotes everything relating to health and fitness,
              while allowing users to earn cryptos. Our token $RNF a utility
              token that&apos;s built on the BSC (Binance Smart Chain) which has
              the lowest transaction fee.
            </p>
            <p className="text-[13px] text-white text-center max-w-[315px]">
              Conceptualized as a smart technology, $RNF Token aims to import
              health and fitness into the crypto space and give members the
              leverage to earn money while keeping fit. Whether you are looking
              to keep fit or your fitness goal is to shed some weight, Runfy
              team is here to help you.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WhatIsRunfy;
