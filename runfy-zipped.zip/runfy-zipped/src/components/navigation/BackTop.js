import React from "react";
import styled from "styled-components";
import { ReactComponent as ArrowTop } from "assets/svgs/arrow-top.svg";

const Wrapper = styled.div`
  height: 69px;
  width: 69px;
  position: fixed;
  opacity: 0;
  pointer-events: none;
  transition: 0.4s ease;
  right: 17px;
  transform: translateY(30px);
  bottom: 50px;
  border-radius: 34.5px;
  .absolute-fill {
    background: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%);
    opacity: 0.1;
  }

  &.backtop-visible {
    opacity: 1;
    pointer-events: auto;
    transform: translateY(0px);
  }
`;

const BackTop = () => {
  return (
    <Wrapper
      className="centers z-[1000] overflow-hidden backtop cursor-pointer"
      onClick={() => (document.documentElement.scrollTop = 0)}
    >
      <div className="absolute-fill" />
      <ArrowTop />
    </Wrapper>
  );
};

export default BackTop;
