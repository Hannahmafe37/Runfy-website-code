import React from "react";
import styled from "styled-components";
import { ReactComponent as Logo } from "assets/svgs/logo.svg";
import { ReactComponent as Twitter } from "assets/svgs/socials/twitter.svg";
import { LINKS } from "utils/constants";

const FooterWrapper = styled.div`
  height: 188px;
  border-radius: 6.5px;
  overflow: hidden;
  .absolute-fill {
    background: linear-gradient(
        261.91deg,
        rgba(114, 233, 126, 0.1) -35.38%,
        rgba(53, 223, 213, 0.1) 126.93%
      ),
      linear-gradient(
        261.91deg,
        rgba(114, 233, 126, 0.1) -35.38%,
        rgba(53, 223, 213, 0.1) 126.93%
      );
  }
`;

const Footer = () => {
  return (
    <div className="mt-[93px]">
      <FooterWrapper className="relative mx-1 be:mx-0">
        <div className="absolute-fill centers flex-col space-y-[18.74px] be:flex-row be:!justify-between be:space-y-0 be:px-[50px]">
          <div className="hidden items-center be:flex space-x-[30px]">
            <a href={LINKS.twitter} rel="noreferrer" target={"_blank"}>
              <Twitter />
            </a>
            <a href={LINKS.telegram} rel="noreferrer" target={"_blank"}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="20"
                viewBox="0 0 24 20"
                fill="none"
              >
                <path
                  d="M23.9511 0.526574C23.9319 0.438003 23.8894 0.356137 23.8281 0.289333C23.7669 0.222529 23.689 0.17318 23.6024 0.146324C23.2873 0.0841712 22.9612 0.107477 22.6581 0.213824C22.6581 0.213824 1.6304 7.77157 0.429648 8.60857C0.170148 8.78858 0.0838979 8.89283 0.0411479 9.01657C-0.166602 9.61207 0.479898 9.87457 0.479898 9.87457L5.8994 11.6408C5.99094 11.6567 6.08491 11.651 6.1739 11.6243C7.4069 10.8458 18.5781 3.79132 19.2239 3.55432C19.3251 3.52357 19.4001 3.55432 19.3836 3.62932C19.1196 4.53382 9.4724 13.1071 9.41915 13.1596C9.39326 13.1808 9.37292 13.208 9.35985 13.2388C9.34679 13.2697 9.3414 13.3032 9.34415 13.3366L8.84015 18.6248C8.84015 18.6248 8.62865 20.2748 10.2756 18.6248C11.4434 17.4556 12.5639 16.4881 13.1256 16.0178C14.9894 17.3041 16.9949 18.7268 17.8596 19.4678C18.0047 19.6088 18.1767 19.719 18.3654 19.7919C18.5541 19.8649 18.7555 19.899 18.9576 19.8923C19.7826 19.8608 20.0076 18.9586 20.0076 18.9586C20.0076 18.9586 23.8386 3.54232 23.9676 1.47607C23.9796 1.27357 23.9969 1.14382 23.9984 1.00507C24.0052 0.844145 23.9893 0.683057 23.9511 0.526574Z"
                  fill="url(#paint0_linear_321_470)"
                />
                <defs>
                  <linearGradient
                    id="paint0_linear_321_470"
                    x1="-3.81175"
                    y1="-11.8104"
                    x2="46.4896"
                    y2="9.15527"
                    gradientUnits="userSpaceOnUse"
                  >
                    <stop stop-color="#fff" />
                    <stop offset="0.515115" stop-color="#fff" />
                    <stop offset="0.859876" stop-color="#fff" />
                    <stop offset="1" stop-color="#fff" />
                  </linearGradient>
                </defs>
              </svg>
            </a>
          </div>
          <Logo />
          <p className="text-[#9EB2CA] text-[13.63px] text-center">
            ©2022 RUNFY TOKEN All rights reserved
          </p>
        </div>
      </FooterWrapper>
      <div className="h-[46px] bg-[#1B1C1C]"></div>
    </div>
  );
};

export default Footer;
