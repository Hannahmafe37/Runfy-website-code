import React, { useEffect } from "react";
import styled from "styled-components";
import clsx from "classnames";
import largewaves from "assets/svgs/large-waves.svg";
import { ReactComponent as ExitIcon } from "assets/svgs/exit-icon.svg";
import { ReactComponent as Logo } from "assets/svgs/logo.svg";

const InnerWrapper = styled.div`
  background: url(${largewaves});
  background-position: center;
  background-size: cover;
  background-repeat: no-repeat;
`;

const links = [
  { name: "About Us", link: "#about" },
  { name: "Features", link: "#features" },
  { name: "Road Map", link: "#roadmap" },
  { name: "FAQs", link: "#faq" },
];

const MobileTopNav = ({ visible, setVisible }) => {
  useEffect(() => {
    if (visible) {
      document.body.classList.add("mobile-nav-visible");
    } else {
      document.body.classList.remove("mobile-nav-visible");
    }
  }, [visible]);

  return (
    <div
      className={clsx(
        "!h-screen bg-[#252626] opacity-0 transition-all pointer-events-none fixed top-0 left-0 w-screen z-[10000] be:opacity-0 be:pointer-events-none",
        {
          "opacity-100 pointer-events-auto be:opacity-0 be:pointer-events-none":
            visible,
        }
      )}
    >
      <InnerWrapper className="overflow-y-auto w-full h-full flex flex-col">
        <div className="flex flex-col space-y-[54.15px] centers mt-[17%]">
          <ExitIcon
            className="cursor-pointer"
            onClick={() => setVisible(false)}
          />
          <ul className="flex flex-col space-y-[23.95px]">
            {links.map((link, index) => (
              <a
                href={link.link}
                key={index}
                className="text-center text-white text-xl"
                onClick={() => setVisible(false)}
              >
                {link.name}
              </a>
            ))}
          </ul>
        </div>
        <div className="flex flex-col centers space-y-[18.74px] mt-auto mb-[11%]">
          <Logo />
          <span className="text-center text-[13.63px] text-[#9EB2CA]">
            ©2022 RUNFY TOKEN All rights reserved
          </span>
        </div>
      </InnerWrapper>
    </div>
  );
};

export default MobileTopNav;
