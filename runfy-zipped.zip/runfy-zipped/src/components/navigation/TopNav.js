import React, { useEffect, useState } from "react";
import clsx from "classnames";
import styled from "styled-components";
import { ReactComponent as Logo } from "assets/svgs/logo.svg";
import { ReactComponent as Hamburger } from "assets/svgs/hamburger.svg";
import { ReactComponent as Union } from "assets/svgs/union.svg";
import { ReactComponent as LargeUnion } from "assets/svgs/large-union.svg";
import { GradientEllipse } from "components/home/Hero";
import { largeScreenClasses, LINKS } from "utils/constants";
import MobileTopNav from "./MobileNav";

const LoginButton = styled.a`
  width: 129px;
  height: 64px;

  /* green gradient */

  background: linear-gradient(261.91deg, #72e97e -35.38%, #35dfd5 126.93%);
  border-radius: 32px;
  padding: 20px 38px;
`;

const TopNav = () => {
  const handleOnScroll = () => {
    if (
      document.body.scrollTop > 20 ||
      document.documentElement.scrollTop > 20
    ) {
      document.getElementById("mynav")?.classList.add("scrolled");
      document.querySelector(".backtop")?.classList.add("backtop-visible");
    } else {
      document.getElementById("mynav")?.classList.remove("scrolled");
      document.querySelector(".backtop")?.classList.remove("backtop-visible");
    }
  };
  useEffect(() => {
    window.addEventListener("scroll", handleOnScroll);
    return () => window.removeEventListener("scroll", handleOnScroll);
  }, []);

  const [mobileNavVisible, setMobileNavVisible] = useState(false);
  return (
    <div id="mynav" className="fixed top-0 left-0 w-screen z-[1000]">
      <MobileTopNav
        visible={mobileNavVisible}
        setVisible={setMobileNavVisible}
      />
      <div
        className={clsx(
          "flex justify-between h-[145px] relative items-center px-[22px] be:px-[40px]",
          largeScreenClasses
        )}
      >
        <Logo />
        <Hamburger
          className="be:hidden cursor-pointer"
          onClick={() => setMobileNavVisible(true)}
        />
        <ul className="items-center hidden be:flex space-x-[81px]">
          <a href="#hero" className="text-xl text-white">
            Home
          </a>
          <a href="#about" className="text-xl text-white">
            About
          </a>
          <a href="#features" className="text-xl text-white">
            Features
          </a>
          <a href="#faq" className="text-xl text-white">
            FAQs
          </a>
        </ul>
        <LoginButton
          className="hidden be:flex items-center justify-center"
          href={LINKS.login}
          target="_blank"
          rel="noreferrer"
        >
          <span className="text-[#1B1C1C] text-xl">Login</span>
        </LoginButton>
        <div className="absolute bottom-0 left-0 w-full pointer-events-none">
          <Union className="w-full union xs:hidden" />
          <div className="w-full centers">
            <LargeUnion className="large-union w-full hidden xs:block" />
          </div>
          <GradientEllipse className="nav-gradient" top="20%" left="20%" />
        </div>
      </div>
    </div>
  );
};

export default TopNav;
