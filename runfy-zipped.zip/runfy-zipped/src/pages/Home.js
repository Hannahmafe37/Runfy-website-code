import React from "react";
import gsap from "gsap";
import FAQ from "components/home/FAQ";
import Features from "components/home/Features";
import Hero from "components/home/Hero";
import Presale from "components/home/Presale";
import RoadMap from "components/home/Roadmap";
import Tokenomics from "components/home/Tokenomics";
import VisionAndMission from "components/home/VisionAndMission";
import WhatIsRunfy from "components/home/WhatIsRunfy";
import Footer from "components/navigation/Footer";
import TopNav from "components/navigation/TopNav";
import BackTop from "components/navigation/BackTop";

const Home = () => {
  const home = React.useRef();
  React.useEffect(() => {
    const texts = [
      { id: "runfy-runfy-big-text", stroke: "#72E97E" },
      { id: "runfy-fitness-big-text", stroke: "#F44197" },
      { id: "runfy-earn-big-text", stroke: "#72E97E" },
      { id: "runfy-crypto-big-text", stroke: "#FFF966" },
      { id: "runfy-win-big-text", stroke: "#BDF9C3" },
    ];
    let ctx = gsap.context(() => {
      texts.forEach((text) => {
        const small_id = text.id.replace("big-", "");
        gsap.to(
          [`#${text.id}`, `#${small_id}`, `#${small_id}-2`, `#${text.id}-2`],
          {
            x: 70,
            stroke: text.stroke,
            strokeWidth: 2,
            fill: "rgba(0,0,0,0)",
            yoyo: true,
            repeat: -1,
            duration: 0.5,
            repeatDelay: 0.2,
            ease: "power2.inOut",
            y: -10,
          }
        );
      });
    }, home);

    return () => ctx.revert();
  }, []);
  return (
    <div className="bg-[#252626]" ref={home}>
      <TopNav />
      <Hero />
      <Presale />
      <WhatIsRunfy />
      <VisionAndMission />
      <Features />
      <Tokenomics />
      <RoadMap />
      <FAQ />
      <Footer />
      <BackTop />
    </div>
  );
};

export default Home;
