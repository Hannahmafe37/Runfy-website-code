export const LINKS = {
  login: "https://go.runfytoken.io/login",
  presale: "https://go.runfytoken.io/register",
  whitepaper: "https://runfytoken.io/runfy-whitepaper.pdf",
  telegram: "https://t.me/RunfyTokenOfficial",
  twitter: "https://twitter.com/RunfyToken",
};

export const presale2Date = new Date(2022, 11, 2);
export const largeScreenClasses = "!max-w-6xl !mx-auto";
