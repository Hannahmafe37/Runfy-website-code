/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      screens: {
        xs: "445px",
        be: "1185px",
        vbe: "1400px",
        vvbe: "1600px",
      },
    },
  },
  plugins: [],
};
